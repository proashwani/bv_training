var app = angular.module("app", []);

app.controller("MainController", function ($scope,$http) {
    $scope.name = "Vikash";
    console.log("Hello World!!");
    
    $scope.getUsers = function () {
       console.log("Hello function!!");
         $http.get('http://jsonplaceholder.typicode.com/users').success(
            function(response, status) {
                
                   $scope.users = response || [];
                   console.log($scope.users);
                   console.log("success");
               
                
                }).error(function(data, status) {
                      console.log(status);
                });
          
    };
});