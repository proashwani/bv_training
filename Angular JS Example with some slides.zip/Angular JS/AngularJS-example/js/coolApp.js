var coolApp = angular.module("coolApp", ['ngRoute']);

coolApp.config(function($routeProvider){
   
    $routeProvider.when('/path1',
                            {
                                controller : 'CoolCtrl' ,
                                templateUrl : 'views/view1.html'
                            })
                  .when('/path2',
                                {   controller : 'CoolCtrl' , 
                                    templateUrl : 'views/view2.html'})
                  .otherwise(
                                {redirectTo : '/path1' });
    
});

coolApp.controller("CoolCtrl", function($scope){
   

        console.log($scope.users);
        $scope.users = $scope.users || [{name : "Vikash" , city : "Faridabad"},
                       {name : "Ashwani" , city : "Delhi"},
                       {name : "Saurabh" , city : "Noida"}];
   
    
    $scope.add = function () {
        $scope.users.push({name : $scope.newUser.name , city : $scope.newUser.city});
    };
});