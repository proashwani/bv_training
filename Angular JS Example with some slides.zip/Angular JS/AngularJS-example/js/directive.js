var myDir = angular.module('myDir',[]);

myDir.directive("helloWorld",function () {
 
    return {
        restrict : 'A',
        required : 'id',
       
        link :  function(scope, element, attributes, ngModelCtrl) {
            
          
           thisElement = element[0];
            thisElement.innerHTML = '<>' +attributes['helloWorld'];
        }
    };
    
});