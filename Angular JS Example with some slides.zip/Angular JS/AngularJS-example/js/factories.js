var newApp = angular.module("newApp", []);

newApp.factory("UserFactory", function () {
 factory = {};
    factory.users = [{name : "Vikash" , city : "Faridabad"},
                       {name : "Ashwani" , city : "Delhi"},
                       {name : "Saurabh" , city : "Noida"}];
    factory.getUsers = function () {
     return    factory.users ;
    }
    return factory;
});

newApp.controller("AbetterCtrl", function ($scope, UserFactory){
    $scope.users = factory.getUsers();
});