import { IonicModule } from 'ionic-angular';
import { FooterComponent } from './footer';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [
      FooterComponent
  ],
  exports: [
    FooterComponent
  ],
  imports: [IonicModule],
})
export class FooterComponentModule {}