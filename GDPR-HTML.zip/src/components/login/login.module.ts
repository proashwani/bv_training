import { LoginComponent } from './login';
import { IonicModule } from 'ionic-angular';

import { NgModule } from '@angular/core';

@NgModule({
  declarations: [
      LoginComponent
  ],
  exports: [
    LoginComponent
  ],
  imports: [IonicModule],
})
export class LoginComponentModule {}