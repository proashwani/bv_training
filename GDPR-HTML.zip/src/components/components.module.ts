import { NgModule } from '@angular/core';

import { HeaderComponent } from './header/header';
import { LoginComponent } from './login/login';
import { FooterComponent } from './footer/footer';
import { BannerComponent } from './banner/banner';

@NgModule({
	declarations: [HeaderComponent,
    LoginComponent,
    FooterComponent,
    BannerComponent],
	imports: [],
	exports: [HeaderComponent,
    LoginComponent,
    FooterComponent,
    BannerComponent,
    ]
})
export class ComponentsModule {}
