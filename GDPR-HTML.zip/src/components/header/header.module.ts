import { LoginComponentModule } from './../login/login.module';
import { HeaderComponent } from './header';
import { IonicModule } from 'ionic-angular';

import { NgModule } from '@angular/core';

@NgModule({
    declarations: [
        HeaderComponent
    ],
    exports: [
        HeaderComponent
    ],
    imports: [IonicModule,
        LoginComponentModule],
})
export class HeaderComponentModule { }