import { CustomComponent } from './custom';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [
      CustomComponent
  ],
  exports: [
    CustomComponent
  ]
})
export class CustomComponentModule {}