import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ReportingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@IonicPage()
@Component({
  selector: 'page-reporting',
  templateUrl: 'reporting.html',
})


export class ReportingPage {
  private tabs: string;
  rows = [];
  showFilter = false;
  showHideRow = [];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.tabs = "total";
    this.fetch((data) => {
      this.rows = data;
      for (let i = 0; i < this.rows.length; i++) {
        this.showHideRow[i] = true;
      }
    });
  }
  fetch(cb) {
    const req = new XMLHttpRequest();
    req.open('GET', `assets/data/sampledata.json`);

    req.onload = () => {
      cb(JSON.parse(req.response));
    };

    req.send();
  }

  clickme(i) {
    this.showHideRow[i] = !this.showHideRow[i];
  }
  myevent(event) {
    var target = event.target || event.srcElement || event.currentTarget;
    var idAttr = target.attributes.id;
    var value = idAttr.nodeValue;
    alert(value);
  }
  ionViewDidLoad(): void {
    //console.log('ionViewDidLoad ReportingPage');
  }

}
