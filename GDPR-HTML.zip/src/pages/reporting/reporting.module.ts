import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { HeaderComponentModule } from './../../components/header/header.module';
import { FooterComponentModule } from './../../components/footer/footer.module';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReportingPage } from './reporting';

@NgModule({
  declarations: [
    ReportingPage,
  ],
  imports: [
    IonicPageModule.forChild(ReportingPage),
    FooterComponentModule,
    HeaderComponentModule,
    NgxDatatableModule
  ],
  exports: [
    ReportingPage
  ]
})
export class ReportingPageModule {}
