import { HeaderComponentModule } from './../../components/header/header.module';
import { FooterComponentModule } from './../../components/footer/footer.module';
import { BannerComponent } from './../../components/banner/banner';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomePage } from './home';
@NgModule({
    declarations: [
        HomePage,
        BannerComponent,
    ],
    imports: [
        IonicPageModule.forChild(HomePage),
        FooterComponentModule,
        HeaderComponentModule
    ],
    exports: [],
    providers: [],
})
export class HomePageModule { }