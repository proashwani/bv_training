import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  reqPage: string;
  repPage: string;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.reqPage = 'RequestPage'
    this.repPage = 'ReportingPage'
  }

  navigateToRequest() {
    console.log('Navigating to another module');
    //this.navCtrl.push(RequestPage);
    }
  
    ionViewDidLoad() {
      console.log('ionViewDidLoad HomePage');
    }
  

}
