import { HeaderComponentModule } from './../../components/header/header.module';
import { FooterComponentModule } from './../../components/footer/footer.module';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequestPage } from './request';

@NgModule({
  declarations: [
    RequestPage
  ],
  imports: [
    IonicPageModule.forChild(RequestPage),
    FooterComponentModule,
    HeaderComponentModule
  ],
  exports: [
    RequestPage
  ]
})
export class RequestPageModule { }
